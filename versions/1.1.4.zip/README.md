## RITA (beta)
Translation bot built using `discord.js` and `Google Translate API`.

![GitHub package.json version (branch)](https://img.shields.io/github/package-json/v/ZyC0R3/Rita/1.1.6?label=Stable%20Version&style=plastic)
![GitHub last commit](https://img.shields.io/github/last-commit/ZyC0R3/Rita.svg?style=plastic)
![GitHub](https://img.shields.io/github/license/ZyC0R3/Rita.svg?style=plastic)
![GitHub issues](https://img.shields.io/github/issues-raw/ZyC0R3/Rita.svg?style=plastic)
[![invite](https://img.shields.io/badge/Discord_Support-JOIN-7289DA.svg?style=plastic&)](https://discordapp.com/invite/mgNR64R)


#### Current Test Branch
![GitHub package.json version (branch)](https://img.shields.io/github/package-json/v/ZyC0R3/Rita/test-branch?label=Test%20Version&style=plastic)

```diff
- This Version is Outdated and may contain Bugs. 
- Please use the Latest Stable Version, https://github.com/ZyC0R3/Rita
```

## Table of Contents

01. [Credits & License](#credits-&-license)
02. [Design Team](#design-team)

**For New Bots or Migration from C-3P0 then please refer to the the Latest Stable Version for Instructions.**

## <a name="credits-&-license"></a>Credits & License

This project was originally released by Aziz under the MIT license. He chose to take the project private/commercial at version 0.4.2 Beta. Bobby Johnson forked the project and renamed it Louie after his dog. AlooAkbar forked Louie and added the necessary modifications for simple and free deployment of the bot using Heroku. ZyC0R3 Picked up the fork and as part of a team fixed over 200 errors and brought it in to the modern age, All would like to thank Aziz for his hard work and making these early versions OSS so that others may learn and build on his hard work to share with the community.

## <a name="design-team"></a>Design Team
* Zycore / [ZyC0R3](https://github.com/ZyC0R3)
* Artanis / [ArtanisTheOne](https://github.com/ArtanisTheOne)
* Balthazar / [Jshep89](https://github.com/JShep89)
* Z3US / [cyberlooper](https://github.com/cyberlooper)
* Maddious / [MadIndex](https://github.com/MadIndex)
* defqon.1 / [wdaniel1985](https://github.com/wdaniel1985)

Released under MIT license.
